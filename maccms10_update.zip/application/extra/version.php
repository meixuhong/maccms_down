<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS.COM',
    'url' => 'http://www.maccms.com/',
    'code' => '2019.1000.1023',
    'license' => '免费版',
);
?>